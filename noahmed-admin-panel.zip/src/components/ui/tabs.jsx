import { useState } from 'react';
export function Tabs({ children, value, onValueChange, className }) {
  return <div className={className}>{children}</div>;
}
export function TabsList({ children, className }) {
  return <div className={className}>{children}</div>;
}
export function TabsTrigger({ children, value }) {
  return <button className='p-2 border rounded'>{children}</button>;
}
export function TabsContent({ children, value }) {
  return <div>{children}</div>;
}
