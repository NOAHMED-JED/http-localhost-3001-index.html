import AdminPanel from './AdminPanel';
export default function App() { return <AdminPanel />; }