const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('YOUR_MONGODB_CONNECTION_STRING', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const diseaseSchema = new mongoose.Schema({
  name: String,
  symptoms: [String],
  medicines: [String]
});

const Disease = mongoose.model('Disease', diseaseSchema);

app.get('/diseases', async (req, res) => {
  const diseases = await Disease.find();
  res.json(diseases);
});

app.listen(3000, () => console.log('API running on http://localhost:3000'));
