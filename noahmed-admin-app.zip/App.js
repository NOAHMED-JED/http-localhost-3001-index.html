// React Native app main file
// You can paste the current code from the canvas here.
