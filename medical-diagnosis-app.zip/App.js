import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { View, Text, Button, ScrollView, Alert } from 'react-native';
import Checkbox from 'expo-checkbox';

const SYMPTOMS = [
  'Fever', 'Cough', 'Headache', 'Fatigue', 'Runny Nose', 'Sore Throat'
];

export default function App() {
  const [selectedSymptoms, setSelectedSymptoms] = useState([]);
  const [diseases, setDiseases] = useState([]);

  useEffect(() => {
    axios.get('http://YOUR_API_URL:3000/diseases')
      .then(res => setDiseases(res.data))
      .catch(err => console.error(err));
  }, []);

  const toggleSymptom = (symptom) => {
    if (selectedSymptoms.includes(symptom)) {
      setSelectedSymptoms(selectedSymptoms.filter(s => s !== symptom));
    } else {
      setSelectedSymptoms([...selectedSymptoms, symptom]);
    }
  };

  const diagnose = () => {
    const matches = diseases.filter(d =>
      d.symptoms.some(symptom => selectedSymptoms.includes(symptom))
    );

    if (matches.length === 0) {
      Alert.alert('Diagnosis', 'No matching disease found.');
      return;
    }

    const result = matches.map(d =>
      `${d.name}\nSuggested medicines: ${d.medicines.join(', ')}`
    ).join('\n\n');

    Alert.alert('Possible Diagnosis', result + '\n\n⚠️ This is not a medical substitute.');
  };

  return (
    <ScrollView style={{ padding: 20 }}>
      <Text style={{ fontSize: 22, fontWeight: 'bold', marginBottom: 10 }}>Select Your Symptoms:</Text>
      {SYMPTOMS.map(symptom => (
        <View key={symptom} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
          <Checkbox value={selectedSymptoms.includes(symptom)} onValueChange={() => toggleSymptom(symptom)} />
          <Text style={{ marginLeft: 8 }}>{symptom}</Text>
        </View>
      ))}
      <Button title="Diagnose" onPress={diagnose} />
    </ScrollView>
  );
}
